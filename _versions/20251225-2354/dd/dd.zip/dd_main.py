"""
dd_main.py v4.9.0 - Programme principal DD (Détecteur Distribué)
Mode SÉQUENTIEL uniquement : répond aux commandes POLL:XX du TA
Module: WROVER-T7 uniquement

Description:
    Programme principal d'un module DD. Attend les commandes du Terminal
    Administrateur (TA) via UART RS-485, mesure l'état du capteur, et répond
    avec l'état détecté. Gère la batterie LiPo et l'entrée en mode OTA 
    pour mises à jour sans fil.

Fonctionnalités:
    - Communication série UART à 9600 bauds
    - Lecture anti-rebond du capteur (20 échantillons sur 20ms)
    - Gestion batterie LiPo avec LEDs d'état rouge/verte
    - Mode OTA via flag NVS et redémarrage
    - LED interne pulse pendant activité
    - Statistiques périodiques
    - Watchdog optionnel

Protocole de communication:
    TA → DD: "POLL:XX\n"        (XX = ID du DD)
    DD → TA: "ACK:XX:Y\n"       (Y = état capteur 0 ou 1)
    
    TA → DD: "OTA:START\n"
    DD → TA: "OTA:ACK:XX\n"     puis redémarrage en mode OTA

Gestion batterie:
    - Mesure tension via ADC GPIO35 (diviseur 1/2)
    - Facteur de calibration en NVS (bat_cal_factor)
    - LEDs rouge/verte selon niveau et charge USB
    - Seuils: UBAT_HIGH=4.0V, UBAT_MID=3.7V, UBAT_LOW=3.5V

Changelog:
v4.9.0 (22/12/2024):
    - Suppression complète du support WROOM-32
    - Code simplifié pour WROVER-T7 uniquement
    - Suppression de MODULE_TYPE et HAS_BATTERY (toujours vrai)
    - Configuration hardware directe sans conditions

v4.8.4 (21/12/2024):
    - Fix: Élimination définitive du double clignotement LED activité
    - Synchronisation du cycle LED avec la réception des POLL

v4.8.3 (19/12/2024):
    - Fix: Correction double clignotement LED activité
    - Séparation propre de la logique de réinitialisation du cycle LED

Auteur: Système DTD
Date: 22/12/2024
"""

from machine import UART, Pin, ADC
import time
import machine
import utils.nvs_utils as nvs_utils

try:
    from machine import WDT
except ImportError:
    WDT = None

try:
    from time import ticks_ms, ticks_diff
except ImportError:
    def ticks_ms():
        return int(time.time() * 1000)
    def ticks_diff(a, b):
        return a - b

# ================================================================
# CONSTANTES
# ================================================================
DEV_MODE = False
WATCHDOG_ENABLED = False
WATCHDOG_MS = 30000
STAT_PERIOD = 5000

UBAT_HIGH = 4.0
UBAT_MID = 3.7
UBAT_LOW = 3.5

UART_BAUD = 9600
DEBOUNCE_SAMPLES = 20
DEBOUNCE_DELAY_US = 1000
BAT_LED_BLINK_MS = 500
BAT_VOLTAGE_DIVIDER = 2.0
AUTO_START = True

# Gestion LED interne sur activité
ACTIVITY_LED_TIMEOUT_MS = 1000   # 1 seconde d'inactivité avant extinction
ACTIVITY_LED_ON_MS = 100         # Durée d'allumage: 100ms (pulse visible)
ACTIVITY_LED_PERIOD_MS = 1000    # Période: pulse toutes les 1000ms

# ================================================================
# CONFIGURATION HARDWARE - WROVER-T7
# ================================================================
# Configuration des pins pour WROVER-T7
UART_TX_PIN = 18
UART_RX_PIN = 23
RADIO_SET_PIN = 26
LED_INTERNAL_PIN = 19
BIT0_PIN = 27
BIT1_PIN = 25
BIT2_PIN = 32
DD_STATUS_PIN = 33

# Gestion batterie
BATTERY_ADC_PIN = 35
LED_RED_PIN = 22
LED_GREEN_PIN = 21
USB_POWER_PIN = 2

# ================================================================
# LECTURE DD_ID (Hardware Straps) - Une seule fois au début
# ================================================================
def read_dd_id():
    """Lit l'ID hardware via les straps (0-7)"""
    try:
        p0 = Pin(BIT0_PIN, Pin.IN, Pin.PULL_UP)
        p1 = Pin(BIT1_PIN, Pin.IN, Pin.PULL_UP)
        p2 = Pin(BIT2_PIN, Pin.IN, Pin.PULL_UP)
        
        bit0 = 0 if p0.value() == 0 else 1
        bit1 = 0 if p1.value() == 0 else 1
        bit2 = 0 if p2.value() == 0 else 1
        
        return (bit2 << 2) | (bit1 << 1) | bit0
    except Exception as e:
        print("[ERREUR] Lecture DD_ID:", e)
        return 0

# Lecture de l'ID matériel (une seule fois au niveau module)
DD_ID = read_dd_id()

# ================================================================
# VARIABLES GLOBALES
# ================================================================
STATUS_PIN = Pin(DD_STATUS_PIN, Pin.IN, Pin.PULL_UP)

# Configuration batterie
BAT_ADC = ADC(Pin(BATTERY_ADC_PIN))
try:
    BAT_ADC.atten(ADC.ATTN_11DB)
except AttributeError:
    pass

LED_RED = Pin(LED_RED_PIN, Pin.OUT)
LED_GREEN = Pin(LED_GREEN_PIN, Pin.OUT)
LED_RED.value(0)
LED_GREEN.value(0)

# Detection USB power sur GPIO2
USB_POWER = Pin(USB_POWER_PIN, Pin.IN, Pin.PULL_DOWN)

LED_INTERNAL = Pin(LED_INTERNAL_PIN, Pin.OUT)
LED_INTERNAL.value(0)

# Variables pour clignotement batterie
blink_green = False
blink_red = False
blink_both = False  # Pour synchroniser rouge et vert (orange)
last_bat_blink_ms = ticks_ms()

# Variables pour LED interne sur activité
last_poll_time_ms = 0
last_activity_led_cycle_ms = ticks_ms()  # Début du dernier cycle
activity_led_state = False  # État actuel de la LED activité

# Statistiques
stats_loop_count = 0
stats_poll_received = 0
stats_ack_sent = 0

battery_correction_factor = 1.0

# ================================================================
# ÉTAT DÉTECTEUR
# ================================================================
def measure_state():
    samples = 0
    for _ in range(DEBOUNCE_SAMPLES):
        if STATUS_PIN.value() == 0:
            samples += 1
        time.sleep_us(DEBOUNCE_DELAY_US)
    return 1 if samples >= (DEBOUNCE_SAMPLES // 2 + 1) else 0

# ================================================================
# BATTERIE
# ================================================================
def load_battery_calibration():
    global battery_correction_factor
    try:
        factor = nvs_utils.get_f32("DTD", "bat_cal_factor", default=1.0)
        if 0.5 <= factor <= 2.0:
            battery_correction_factor = factor
        else:
            battery_correction_factor = 1.0
    except Exception as e:
        battery_correction_factor = 1.0

def read_battery_voltage():
    try:
        raw = BAT_ADC.read()
        voltage_adc = (raw / 4095.0) * 3.3
        voltage_bat = voltage_adc * BAT_VOLTAGE_DIVIDER * battery_correction_factor
        return voltage_bat
    except:
        return None

def update_battery_leds(voltage):
    """
    Gestion des LEDs selon tension batterie et présence USB
    
    UBAT_HIGH = 4.0V
    UBAT_MID = 3.7V
    UBAT_LOW = 3.5V
    
    USB OFF (gpio2=0):
        Ubat >= UBAT_MID      : Vert ON,  Rouge OFF
        UBAT_LOW <= Ubat < UBAT_MID : Vert ON,  Rouge ON (orange fixe)
        Ubat < UBAT_LOW        : Vert OFF, Rouge ON
    
    USB ON (gpio2=1):
        Ubat > UBAT_HIGH      : Vert ON,  Rouge OFF
        Ubat >= UBAT_MID      : Vert clignotant, Rouge OFF
        UBAT_LOW <= Ubat < UBAT_MID : Vert+Rouge clignotants synchronisés (orange clignotant)
        Ubat < UBAT_LOW        : Vert OFF, Rouge clignotant
    """
    global blink_green, blink_red, blink_both
    
    if voltage is None:
        return
    
    usb_present = USB_POWER.value()
    
    if not usb_present:
        # USB OFF - LEDs fixes
        blink_green = False
        blink_red = False
        blink_both = False
        
        if voltage >= UBAT_MID:
            LED_GREEN.value(1)
            LED_RED.value(0)
        elif voltage >= UBAT_LOW:
            # Orange fixe (vert + rouge)
            LED_GREEN.value(1)
            LED_RED.value(1)
        else:  # < UBAT_LOW
            LED_GREEN.value(0)
            LED_RED.value(1)
    
    else:
        # USB ON - LEDs clignotantes selon tension
        if voltage > UBAT_HIGH:
            # Charge complète
            blink_green = False
            blink_red = False
            blink_both = False
            LED_GREEN.value(1)
            LED_RED.value(0)
        elif voltage >= UBAT_MID:
            # Charge en cours, tension bonne
            blink_green = True
            blink_red = False
            blink_both = False
            LED_RED.value(0)
        elif voltage >= UBAT_LOW:
            # Charge en cours, tension moyenne
            # Orange clignotant: vert et rouge synchronisés
            blink_green = False
            blink_red = False
            blink_both = True
        else:  # < UBAT_LOW
            # Charge en cours, tension basse
            blink_green = False
            blink_red = True
            blink_both = False
            LED_GREEN.value(0)

def update_blinking_leds():
    """Gère le clignotement des LEDs batterie"""
    global last_bat_blink_ms
    
    now = ticks_ms()
    if ticks_diff(now, last_bat_blink_ms) < BAT_LED_BLINK_MS:
        return
    last_bat_blink_ms = now
    
    # Si les deux doivent clignoter ensemble (orange)
    if blink_both:
        new_state = 0 if LED_GREEN.value() else 1
        LED_GREEN.value(new_state)
        LED_RED.value(new_state)
    else:
        # Clignotement indépendant
        if blink_green:
            LED_GREEN.value(0 if LED_GREEN.value() else 1)
        if blink_red:
            LED_RED.value(0 if LED_RED.value() else 1)

def update_activity_led():
    """
    Gère la LED interne basée sur l'activité POLL
    S'allume 100ms toutes les 1000ms quand il y a de l'activité
    """
    global last_activity_led_cycle_ms, activity_led_state
    
    now = ticks_ms()
    
    # Vérifier si on a eu une activité récente (< 1 seconde)
    if last_poll_time_ms > 0 and ticks_diff(now, last_poll_time_ms) < ACTIVITY_LED_TIMEOUT_MS:
        # Activité récente: gérer le cycle de clignotement
        time_in_cycle = ticks_diff(now, last_activity_led_cycle_ms)
        
        # Si on dépasse la période, recommencer un nouveau cycle
        if time_in_cycle >= ACTIVITY_LED_PERIOD_MS:
            if DEV_MODE:
                print("[LED] Nouveau cycle à t={}ms".format(now))
            last_activity_led_cycle_ms = now
            time_in_cycle = 0
        
        # Déterminer si la LED doit être allumée selon la position dans le cycle
        should_be_on = (time_in_cycle < ACTIVITY_LED_ON_MS)
        
        # Changer l'état seulement si nécessaire
        if should_be_on != activity_led_state:
            LED_INTERNAL.value(1 if should_be_on else 0)
            activity_led_state = should_be_on
            if DEV_MODE:
                print("[LED] Changement: {} à time_in_cycle={}ms".format("ON" if should_be_on else "OFF", time_in_cycle))
    else:
        # Pas d'activité récente: éteindre
        if activity_led_state:
            LED_INTERNAL.value(0)
            activity_led_state = False
            if DEV_MODE:
                print("[LED] Extinction (pas d'activité)")
        last_activity_led_cycle_ms = now

def check_battery_and_stats(loop_count):
    global stats_loop_count, stats_poll_received
    global stats_ack_sent
    
    if stats_poll_received > 0:
        pct = (stats_ack_sent / stats_poll_received) * 100
    else:
        pct = 0.0
    
    voltage = read_battery_voltage()
    update_battery_leds(voltage)
    
    if DEV_MODE:
        if voltage is not None:
            print("[STATS] Iter:{} POLL:{} ACK:{} Taux:{:.1f}% [bat]{:.2f}V"
                  .format(stats_loop_count, stats_poll_received,
                         stats_ack_sent, pct, voltage))
        else:
            print("[STATS] Iter:{} POLL:{} ACK:{} Taux:{:.1f}%"
                  .format(stats_loop_count, stats_poll_received,
                         stats_ack_sent, pct))

# ================================================================
# RADIO
# ================================================================
def init_radio():
    try:
        p = Pin(RADIO_SET_PIN, Pin.OUT)
        p.value(1)
    except Exception as e:
        print("[WARN] Config SET pin:", e)
    
    uart = UART(
        1,
        baudrate=UART_BAUD,
        tx=Pin(UART_TX_PIN),
        rx=Pin(UART_RX_PIN),
        timeout=10,
    )
    return uart

# ================================================================
# MODE SÉQUENTIEL - Traitement POLL:XX
# ================================================================
def handle_poll_sequential(uart, line):
    global stats_ack_sent, last_poll_time_ms, last_activity_led_cycle_ms
    
    try:
        req_id = int(line[5:])
    except:
        return
    
    if req_id == DD_ID:
        # Enregistrer l'heure de la dernière activité POLL
        # ET redémarrer le cycle de la LED activité
        last_poll_time_ms = ticks_ms()
        last_activity_led_cycle_ms = last_poll_time_ms
        
        state = measure_state()
        response = "ACK:{:02d}:{}\n".format(DD_ID, state)
        uart.write(response)
        stats_ack_sent += 1
        
        if DEV_MODE:
            print("[POLL] DD{:02d} state={} → ACK envoyé".format(DD_ID, state))

# ================================================================
# OTA - Flag NVS et redémarrage
# ================================================================
def enter_ota_via_reboot(uart):
    """
    Entre en mode OTA via flag NVS + reboot
    Ceci garantit que OTA démarre avec mémoire propre
    """
    
    # Envoyer ACK OTA
    try:
        uart.write("OTA:ACK:{:02d}\n".format(DD_ID))
    except:
        pass
    
    print(">>> OTA MODE <<<")
    print("[OTA] Flag NVS + Reboot...")
    
    # Écrire flag OTA en NVS
    nvs_utils.set_i32("DTD", "ota_mode", 1)
    
    # Attendre que l'ACK parte
    time.sleep_ms(250)
    
    # Redémarrer - boot.py détectera le flag et lancera OTA directement
    machine.reset()

# ================================================================
# BOUCLE PRINCIPALE
# ================================================================
def main():
    global stats_loop_count, stats_poll_received
    
    load_battery_calibration()
    uart = init_radio()
    
    if WATCHDOG_ENABLED and WDT is not None:
        wdt = WDT(timeout=WATCHDOG_MS)
    else:
        wdt = None
    
    print("-" * 70)
    print("DTD v4.9.0 | ID={:02d} | Module: WROVER-T7".format(DD_ID))
    print("DD_ID = {:02d} | MODE SÉQUENTIEL".format(DD_ID))
    print("DEV={} | STAT_PERIOD={} | WATCHDOG={}".format(DEV_MODE, STAT_PERIOD, WATCHDOG_ENABLED))
    print("-" * 70)
    
    # Affichage immédiat de l'état batterie au boot
    voltage = read_battery_voltage()
    if voltage is not None:
        update_battery_leds(voltage)
        print("[BOOT] Batterie: {:.2f}V | USB: {}".format(voltage, "OUI" if USB_POWER.value() else "NON"))
        print("-" * 70)    
    buffer = b""
    loop_count = 0
    
    while True:
        loop_count += 1
        stats_loop_count = loop_count
        
        # Lecture UART
        if uart.any():
            b = uart.read(1)
            if b:
                buffer += b
                
                if buffer.endswith(b"\n"):
                    try:
                        line = buffer.decode().strip()
                    except:
                        line = ""
                    buffer = b""
                    
                    # === TRAITEMENT DES COMMANDES ===
                    if line.startswith("POLL:"):
                        stats_poll_received += 1
                        handle_poll_sequential(uart, line)
                    
                    elif "OTA:START" in line:
                        # Passage en mode OTA via flag NVS + reboot
                        enter_ota_via_reboot(uart)
                        # Ne revient jamais
        
        if wdt is not None:
            wdt.feed()
        
        if loop_count % STAT_PERIOD == 0:
            check_battery_and_stats(loop_count)
        
        # Mise à jour des LEDs
        update_blinking_leds()
        update_activity_led()
        
        time.sleep_ms(1)


# ================================================================
# POINT D'ENTRÉE
# ================================================================
if AUTO_START:
    try:
        main()
    except KeyboardInterrupt:
        print("\n[INFO] Arrêt demandé")
    except Exception as e:
        print("\n[ERREUR CRITIQUE]", e)
        import sys