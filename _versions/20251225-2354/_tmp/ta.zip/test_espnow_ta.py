"""
test_espnow_ta.py - Test ESP-NOW sur le TA

Script simple pour tester la communication ESP-NOW.
À exécuter dans le REPL du TA pour vérifier que tout fonctionne.

Usage:
>>> import test_espnow_ta
>>> test_espnow_ta.test_basic()      # Test de base
>>> test_espnow_ta.test_poll_dd(0)   # Test avec DD spécifique
>>> test_espnow_ta.get_ta_mac()      # Afficher MAC du TA
"""

import network
import espnow
import time

def get_ta_mac():
    """Affiche le MAC du TA"""
    sta = network.WLAN(network.STA_IF)
    sta.active(True)
    mac_bytes = sta.config('mac')
    mac_str = ':'.join('{:02X}'.format(b) for b in mac_bytes)
    print("MAC du TA: {}".format(mac_str))
    print("\nConfigurer ce MAC sur chaque DD avec:")
    print("nvs_utils.set_str('DTD', 'ta_mac', '{}')".format(mac_str))
    return mac_str

def test_basic():
    """Test de base ESP-NOW"""
    print("="*50)
    print("Test ESP-NOW de base")
    print("="*50)
    
    # Init WiFi
    sta = network.WLAN(network.STA_IF)
    sta.active(True)
    print("✓ WiFi activé")
    
    # Init ESP-NOW
    esp = espnow.ESPNow()
    esp.active(True)
    print("✓ ESP-NOW activé")
    
    # Afficher MAC
    mac_str = get_ta_mac()
    
    # Test broadcast
    print("\nEnvoi d'un POLL en broadcast...")
    msg = b"POLL:00\n"
    esp.send(None, msg)
    print("✓ POLL envoyé")
    
    # Attendre réponse
    print("Attente de réponse (5s)...")
    deadline = time.ticks_ms() + 5000
    
    while time.ticks_diff(deadline, time.ticks_ms()) > 0:
        host, msg = esp.recv(0)
        if msg:
            rssi = sta.status('rssi')
            mac_dd = ':'.join('{:02X}'.format(b) for b in host)
            print("\n✓ Réponse reçue!")
            print("  De: {}".format(mac_dd))
            print("  Message: {}".format(msg.decode().strip()))
            print("  RSSI: {} dBm".format(rssi))
            
            # Ajouter comme peer
            esp.add_peer(host)
            print("  → DD ajouté comme peer")
            break
        time.sleep_ms(10)
    else:
        print("✗ Pas de réponse (timeout)")
    
    # Cleanup
    esp.active(False)
    print("\nTest terminé")

def test_poll_dd(dd_id):
    """Test POLL d'un DD spécifique"""
    print("="*50)
    print("Test POLL DD{:02d}".format(dd_id))
    print("="*50)
    
    # Init
    sta = network.WLAN(network.STA_IF)
    sta.active(True)
    
    esp = espnow.ESPNow()
    esp.active(True)
    
    print("Envoi POLL:{:02d}...".format(dd_id))
    msg = "POLL:{:02d}\n".format(dd_id).encode()
    esp.send(None, msg)
    
    # Attendre ACK
    print("Attente ACK (2s)...")
    deadline = time.ticks_ms() + 2000
    
    while time.ticks_diff(deadline, time.ticks_ms()) > 0:
        host, msg = esp.recv(0)
        if msg:
            line = msg.decode().strip()
            if line.startswith("ACK:"):
                rssi = sta.status('rssi')
                mac_dd = ':'.join('{:02X}'.format(b) for b in host)
                
                parts = line.split(":")
                recv_id = int(parts[1])
                state = int(parts[2])
                
                print("\n✓ ACK reçu!")
                print("  DD: {:02d}".format(recv_id))
                print("  État: {} ({})".format(state, "PRESENT" if state == 1 else "ABSENT"))
                print("  MAC: {}".format(mac_dd))
                print("  RSSI: {} dBm".format(rssi))
                break
        time.sleep_ms(2)
    else:
        print("✗ Pas d'ACK (timeout)")
    
    esp.active(False)
    print("\nTest terminé")

def test_all_dd():
    """Test séquentiel de tous les DD"""
    print("="*50)
    print("Test séquentiel de tous les DD")
    print("="*50)
    
    # Init
    sta = network.WLAN(network.STA_IF)
    sta.active(True)
    
    esp = espnow.ESPNow()
    esp.active(True)
    
    # Tester DD 0 à 7
    for dd_id in range(8):
        print("\nPOLL DD{:02d}...".format(dd_id))
        msg = "POLL:{:02d}\n".format(dd_id).encode()
        esp.send(None, msg)
        
        # Attendre ACK
        deadline = time.ticks_ms() + 500
        found = False
        
        while time.ticks_diff(deadline, time.ticks_ms()) > 0:
            host, msg = esp.recv(0)
            if msg:
                line = msg.decode().strip()
                if line.startswith("ACK:"):
                    parts = line.split(":")
                    recv_id = int(parts[1])
                    state = int(parts[2])
                    rssi = sta.status('rssi')
                    
                    if recv_id == dd_id:
                        print("  ✓ DD{:02d}: {} (RSSI: {} dBm)".format(
                            dd_id, "PRESENT" if state == 1 else "ABSENT", rssi))
                        found = True
                        break
            time.sleep_ms(2)
        
        if not found:
            print("  ✗ DD{:02d}: Pas de réponse".format(dd_id))
    
    esp.active(False)
    print("\nTest terminé")

if __name__ == "__main__":
    print("\n=== Tests ESP-NOW pour TA ===\n")
    print("Commandes disponibles:")
    print("  test_basic()       - Test de base")
    print("  test_poll_dd(N)    - Test DD spécifique")
    print("  test_all_dd()      - Test tous les DD")
    print("  get_ta_mac()       - Afficher MAC du TA")
    print("\nExemple:")
    print(">>> import test_espnow_ta")
    print(">>> test_espnow_ta.test_basic()")
