# TA ESP-NOW v3.0.0 - Migration 433MHz → ESP-NOW

## Changements principaux

### ✅ Ajouté
- Module `ta_radio_espnow.py` pour communication ESP-NOW
- RSSI moyen affiché dans les stats
- RSSI individuel par DD stocké et loggé
- Ajout automatique des DD comme peers

### 🔄 Modifié
- `ta_app.py` v3.0.0 : Import de `RadioESPNow` au lieu de `Radio433`
- Message de statut inclut maintenant RSSI moyen
- Logs de changement d'état incluent RSSI individuel

### ❌ Supprimé
- Dépendance au module UART GT38 433MHz
- Pins GPIO 43, 44, 45 (maintenant libres)
- Configuration `UART_RADIO` dans `ta_config.py` (peut rester, ignorée)

### ✓ Identique
- Protocole: POLL:XX → ACK:XX:Y
- Mode séquentiel conservé
- Interface utilisateur inchangée
- Gestion boutons inchangée
- Gestion batterie inchangée
- Structure ta_app.py identique

## Fichiers modifiés

### Nouveaux fichiers
```
ta_radio_espnow.py     # Remplace ta_radio_433.py
```

### Fichiers modifiés
```
ta_app.py              # v3.0.0 - Import RadioESPNow
```

### Fichiers inchangés
```
ta_main.py             # Identique
ta_ui_portrait.py      # Identique
ta_buttons.py          # Identique
ta_logger.py           # Identique
ta_config.py           # Identique (UART_RADIO ignoré)
ta_ota.py              # Identique
boot.py                # Identique
tft_config_amoled.py   # Identique
```

## Déploiement

### Fichiers à téléverser sur le TA

**Obligatoires (nouveaux/modifiés):**
```
ta_radio_espnow.py     # Nouveau module radio
ta_app.py              # Version modifiée v3.0.0
```

**Optionnels (si pas déjà présents):**
```
ta_main.py
ta_ui_portrait.py
ta_buttons.py
ta_logger.py
ta_config.py
ta_ota.py
boot.py
tft_config_amoled.py
```

### Configuration

**Aucune configuration nécessaire !**

L'ESP-NOW fonctionne en broadcast pour les POLL, les DD répondent directement et sont ajoutés automatiquement comme peers lors de la première réponse.

## Test de communication

### Au démarrage du TA

```
[radio] ESP-NOW initialisé
[radio] TA MAC: 24:6F:28:XX:YY:ZZ
[app] Init OK - ESP-NOW
[app] Demarrage scan ESP-NOW...
```

### Lors de la réception d'un DD

```
[radio] DD ajouté: AA:BB:CC:DD:EE:FF
[radio] ← ACK DD00 state=1 RSSI:-45dBm
[app] DD0: PRESENT RSSI:-45dBm (idx=0)
```

### Dans les stats (mode debug)

```
STATS: P=3 A=2 U=0 loops=127 errors=0 RSSI:-52
```

## Fonctionnalités ESP-NOW

### RSSI disponible

**Par DD:**
```python
rssi = radio.get_rssi(dd_id)  # RSSI spécifique d'un DD
```

**Moyen:**
```python
stats = radio.get_stats()
avg_rssi = stats.get("avg_rssi")  # RSSI moyen de tous les DD
```

**À l'écran:**
Le message de statut affiche maintenant:
```
ON:3 OFF:2 ?:0  L:127 RSSI:-52
```

### Ajout automatique des DD

Les DD sont ajoutés automatiquement comme peers lors de leur première réponse ACK. Pas besoin de configuration manuelle des MACs.

### Statistiques

Nouvelles stats disponibles:
```python
{
    "tx_count": 150,        # Nombre de POLL envoyés
    "rx_count": 145,        # Nombre d'ACK reçus
    "timeout_count": 5,     # Nombre de timeouts
    "error_count": 0,       # Erreurs envoi
    "parse_errors": 0,      # Erreurs parsing
    "decode_errors": 0,     # Erreurs décodage
    "avg_rssi": -52         # RSSI moyen (dBm)
}
```

## GPIOs libérés sur le TA

Avec ESP-NOW, ces GPIOs sont maintenant **disponibles**:

- **GPIO 43** (ex-UART TX 433MHz)
- **GPIO 44** (ex-UART RX 433MHz)
- **GPIO 45** (ex-PIN_GT38_SET)

Soit 3 GPIOs pour extensions futures!

## Comparaison 433MHz vs ESP-NOW

| Critère | Radio 433MHz | ESP-NOW |
|---------|--------------|---------|
| Matériel | Module GT38 | Aucun (intégré) |
| Pins utilisés | 3 (TX/RX/SET) | 0 |
| RSSI | ❌ | ✅ |
| Coût | ~10-15€ | 0€ |
| Portée | ~1-2 km | 300m (1km avec antenne externe) |
| Débit | 9600 baud | 1 Mbps |
| Latence | ~50ms | <20ms |
| Configuration | UART complexe | Aucune |

## Dépannage

### Pas de communication avec les DD

1. **Vérifier le TA:**
   - ESP-NOW initialisé ? → `[radio] ESP-NOW initialisé`
   - MAC du TA affiché ? → `[radio] TA MAC: XX:XX:XX:XX:XX:XX`

2. **Vérifier les DD:**
   - MAC du TA configuré en NVS ? → `nvs_utils.get_str("DTD", "ta_mac")`
   - DD en v5.0.0 ESP-NOW ?

3. **Vérifier la portée:**
   - RSSI < -70 dBm = trop loin ou obstacles
   - Rapprocher les DD du TA pour test

### Stats montrent beaucoup de timeouts

- Vérifier RSSI moyen (doit être > -70 dBm)
- Réduire `REPLY_TIMEOUT_MS` dans `ta_config.py` si trop court
- Augmenter si environnement bruité

### DD pas ajouté automatiquement

Le DD sera ajouté lors de sa première réponse ACK. Si jamais de réponse:
- Vérifier que le DD a bien le MAC du TA en NVS
- Vérifier que le DD est en v5.0.0 ESP-NOW
- Vérifier la portée (<300m sans antenne externe)

## Compatibilité

### TA v3.0.0 ESP-NOW
- ✅ Compatible avec DD v5.0.0 ESP-NOW
- ❌ **PAS** compatible avec DD v4.9.0 RS-485

### Migration progressive impossible

Vous devez migrer **tous les DD** en même temps vers ESP-NOW.
Impossible de mixer DD ESP-NOW et DD RS-485 sur le même TA.

## Version

**v3.0.0** - Migration ESP-NOW (25/12/2024)
- Communication sans fil
- RSSI disponible
- 3 GPIOs libérés
- Performance améliorée
